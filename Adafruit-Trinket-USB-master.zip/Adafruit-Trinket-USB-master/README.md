# Adafruit-Trinket-USB
Arduino libraries allowing Trinket to act as USB devices

NOTE:  This folder contains multiple libraries.  Each library must be installed individually.  Simply installing the master folder won't work.  Move each library folder out of the master after you unzip into your libraries folder.
