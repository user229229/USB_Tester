DigiFi
======

DigiX WiFi Library for the WIFI232-G Module
